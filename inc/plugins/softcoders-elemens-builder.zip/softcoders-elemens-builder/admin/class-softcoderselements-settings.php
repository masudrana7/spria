<?php
defined( 'ABSPATH' ) or exit;

class softcoderselements_Settings{
    public function __construct(){
        //
        
    }
}
