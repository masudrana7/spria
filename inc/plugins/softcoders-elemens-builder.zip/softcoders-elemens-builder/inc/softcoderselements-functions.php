<?php
/**
 * Header Footer Elementor Function
 */

/**
 * Checks if Header is enabled from HFE.
 *
 * @since  1.0.0
 * @return bool True if header is enabled. False if header is not enabled
 */


if ( ! function_exists( 'rt_get_cf7_forms' ) ) {
    /**
     * Get a list of all CF7 forms
     *
     * @return array
     */
    function rt_get_cf7_forms() {
        $forms = get_posts( [
            'post_type'      => 'wpcf7_contact_form',
            'post_status'    => 'publish',
            'posts_per_page' => -1,
            'orderby'        => 'title',
            'order'          => 'ASC',
        ] );

        if ( ! empty( $forms ) ) {
            return wp_list_pluck( $forms, 'post_title', 'ID' );
        }
        return [];
    }
}

function socoders_elements_header_enabled() {
	$header_id = Header_Footer_Elementor::get_settings( 'type_header', '' );
	$status    = false;

	if ( '' !== $header_id ) {
		$status = true;
	}

	return apply_filters( 'socoders_elements_header_enabled', $status );
}

/**
 * Checks if Footer is enabled from HFE.
 *
 * @since  1.0.2
 * @return bool True if header is enabled. False if header is not enabled.
 */
function socoders_elements_footer_enabled() {
	$footer_id = Header_Footer_Elementor::get_settings( 'type_footer', '' );
	$status    = false;

	if ( '' !== $footer_id ) {
		$status = true;
	}

	return apply_filters( 'socoders_elements_footer_enabled', $status );
}

/**
 * Get HFE Header ID
 *
 * @since  1.0.2
 * @return (String|boolean) header id if it is set else returns false.
 */
function get_socoders_elements_header_id() {
	$header_id = Header_Footer_Elementor::get_settings( 'type_header', '' );

	if ( '' === $header_id ) {
		$header_id = false;
	}

	return apply_filters( 'get_socoders_elements_header_id', $header_id );
}

/**
 * Get HFE Footer ID
 *
 * @since  1.0.2
 * @return (String|boolean) header id if it is set else returns false.
 */
function get_socoders_elements_footer_id() {
	$footer_id = Header_Footer_Elementor::get_settings( 'type_footer', '' );

	if ( '' === $footer_id ) {
		$footer_id = false;
	}

	return apply_filters( 'get_socoders_elements_footer_id', $footer_id );
}

/**
 * Display header markup.
 *
 * @since  1.0.2
 */
function socoders_elements_render_header() {

	if ( false == apply_filters( 'enable_socoders_elements_render_header', true ) ) {
		return;
	}

	Header_Footer_Elementor::get_header_content();
}

/**
 * Display footer markup.
 *
 * @since  1.0.2
 */
function socoders_elements_render_footer() {
	if ( false == apply_filters( 'enable_socoders_elements_render_footer', true ) ) {
		return;
	}

	?>
		<footer itemtype="https://schema.org/WPFooter" itemscope="itemscope" id="colophon" role="contentinfo">
			<?php Header_Footer_Elementor::get_footer_content(); ?>
		</footer>
	<?php

}

/**
 * Get HFE Before Footer ID
 *
 * @since  1.0.2
 * @return String|boolean before footer id if it is set else returns false.
 */
function socoders_elements_get_before_footer_id() {

	$before_footer_id = Header_Footer_Elementor::get_settings( 'type_before_footer', '' );

	if ( '' === $before_footer_id ) {
		$before_footer_id = false;
	}

	return apply_filters( 'get_socoders_elements_before_footer_id', $before_footer_id );
}



/**
 * Display before footer markup.
 *
 * @since  1.0.2
 */
function socoders_elements_render_before_footer() {

	if ( false == apply_filters( 'enable_socoders_elements_render_before_footer', true ) ) {
		return;
	}

	?>
		<div class="sce-before-footer-wrap">
			<?php Header_Footer_Elementor::get_before_footer_content(); ?>
		</div>
	<?php

}

/**
 * Checks if Before Footer is enabled from HFE.
 *
 * @since  1.0.2
 * @return bool True if before footer is enabled. False if before footer is not enabled.
 */
function socoders_elements_is_before_footer_enabled() {

	$before_footer_id = Header_Footer_Elementor::get_settings( 'type_before_footer', '' );
	$status           = false;

	if ( '' !== $before_footer_id ) {
		$status = true;
	}

	return apply_filters( 'socoders_elements_before_footer_enabled', $status );
}




/**
 * Sidebar Canvas ID
 *
 * @since  1.0.2
 * @return String|boolean before footer id if it is set else returns false.
 */
function socoders_elements_get_sidebar_canvas_id() {

	$sidebar_canvas_id = Header_Footer_Elementor::get_settings( 'type_sidebar_canvas', '' );

	if ( '' === $sidebar_canvas_id ) {
		$sidebar_canvas_id = false;
	}

	return apply_filters( 'get_socoders_elements_sidebar_canvas_id', $sidebar_canvas_id );
}

/**
 * Display before footer markup.
 *
 * @since  1.0.2
 */
function socoders_elements_render_sidebar_canvas() {

	if ( false == apply_filters( 'enable_socoders_elements_render_sidebar_canvas', true ) ) {
		return;
	}

	?>
		<div class="sce-before-footer-wrap">
			<?php Header_Footer_Elementor::get_sidebar_canvas_content(); ?>
		</div>
	<?php

}

/**
 * Checks if Before Footer is enabled from HFE.
 *
 * @since  1.0.2
 * @return bool True if before footer is enabled. False if before footer is not enabled.
 */
function socoders_elements_is_sidebar_canvas_enabled() {
	$sidebar_canvas_id = Header_Footer_Elementor::get_settings( 'type_sidebar_canvas', '' );
	$status           = false;

	if ( '' !== $sidebar_canvas_id ) {
		$status = true;
	}
	return apply_filters( 'socoders_elements_sidebar_canvas_enabled', $status );
}



if ( ! function_exists( 'boxfin_breadcrumb' ) ) {
 function boxfin_breadcrumb()
	{
		$breadcrumb_title = 'boxfin';
		$breadcrumb_class = 'breadcrumb_no_bg';
		if (is_front_page() && is_home()) :
			$breadcrumb_title = ''; // deafult blog
			$breadcrumb_class = 'deafult-home-breadcrumb';
		elseif (is_front_page() && !is_home()) :
			$breadcrumb_title = ''; // custom home or deafult
			$breadcrumb_class = 'custom-home-breadcrumb';
		elseif (is_home()) :
			$breadcrumb_on_off = get_theme_mod('breadcrumb_on_off', '');
			
			if ($breadcrumb_on_off == '1') :
				$blog_breadcrumb_content = get_the_title( get_option( 'page_for_posts', true ) );
				$breadcrumb_title        = $blog_breadcrumb_content;
			else :
				$breadcrumb_title = '';
			endif;
			$breadcrumb_class = 'blog-breadcrumb';
		elseif (is_archive()) :

			$breadcrumb_class = 'blog-breadcrumb';
			$breadcrumb_title = get_the_archive_title();

		elseif (is_single()) :
			if (get_post_type(get_the_ID()) == 'post') :
					$blog_single_breadcrumb_content = get_theme_mod('breadcrumb_title', '');
					if ($blog_single_breadcrumb_content) {
						$breadcrumb_title = $blog_single_breadcrumb_content;
					} else {
						$breadcrumb_title = get_the_title();
					}
					$breadcrumb_class = 'blog-single-breadcrumb';
			else :
				// post type
				$breadcrumb_title = ucfirst(get_post_type()) . esc_html__(' Details', 'boxfin');
				$breadcrumb_class = get_post_type() . '-single-breadcrumb';
			endif;
		elseif (is_404()) :
			$breadcrumb_title = esc_html__('Error Page', 'boxfin');
			$breadcrumb_class = 'blog-breadcrumb';
		elseif (is_search()) :
			if (have_posts()) :
				$breadcrumb_title = esc_html__('Search Results for: ', 'boxfin') . get_search_query();
				$breadcrumb_class = 'blog-breadcrumb';
			else :
				$breadcrumb_title = esc_html__('Nothing Found', 'boxfin');
				$breadcrumb_class = 'blog-breadcrumb';
			endif;
		elseif (!is_home() && !is_front_page() && !is_search() && !is_404()) :
			$breadcrumb_title = get_the_title();
			$breadcrumb_class = 'page-breadcrumb';
		endif;
		$breadcrumb_active_class = 'breadcrumb-not-active';
		if (function_exists('bcn_display')) :
			$breadcrumb_active_class = '';
		endif;
		?>
		<?php
		if (is_page()) {
			$boxfin_show_breadcrumb = '';
			$layout_settings = get_post_meta(get_the_ID(), 'softcoders_layout_settings', true);
			if( isset( $layout_settings['softcoders_breadcrumb']) ) {
				$boxfin_show_breadcrumb = $layout_settings['softcoders_breadcrumb'];
			}
			$boxfin_page_title = '';
			if( isset( $layout_settings['softcoders_brd_page_title']) ) {
				$boxfin_page_title = $layout_settings['softcoders_brd_page_title'];
			}
			if ($boxfin_page_title != '') {
				$breadcrumb_title = $boxfin_page_title;
			} else {
				$breadcrumb_title = get_the_title();
			}
		} else {
			$boxfin_show_breadcrumb = 'on';
		}

		$breadcrumb_class_with_header = 'breadcrumb-class-with-header-one';
		?>
		<?php
		if ( 'off' != $boxfin_show_breadcrumb ) :
		?>
			<?php
			if (isset($breadcrumb_title) && !empty($breadcrumb_title)) :
			?>
			<!--=========== breadcrumb Section Start =========-->
			<div class="sc-breadcrumb-style-hfe sc-breadcrumb-style sc-pt-135 sc-pb-110 <?php echo esc_attr($breadcrumb_class . ' ' . $breadcrumb_active_class . ' ' . $breadcrumb_class_with_header); ?>">
				<div class="container position-relative">
					<div class="row">
						<div class="col-lg-12">
							<div class="sc-slider-content p-z-idex">
							<?php if( function_exists( 'bcn_display') ){ ?>
								<div class="sc-slider-subtitle">
									<ul>
										<?php bcn_display(); ?>
										
									</ul>
								</div>
								<?php } ?>
								<h1 class="slider-title white-color sc-mb-25 sc-sm-mb-15"><?php echo esc_html($breadcrumb_title); ?></h1>
							</div>
						</div>
					</div>
				</div>
			</div>
			<!--=========== breadcrumb Section End =========-->
			<?php
			endif;
			?>
		<?php endif; ?>
		<?php
	}
}