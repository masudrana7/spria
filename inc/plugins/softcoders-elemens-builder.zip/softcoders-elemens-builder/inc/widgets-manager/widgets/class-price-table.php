<?php
namespace softcoderselements\WidgetsManager\Widgets;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Core\Kits\Documents\Tabs\Global_Typography;
use Elementor\Widget_Base;
use Elementor\Core\Kits\Documents\Tabs\Global_Colors;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Repeater;

if ( ! defined( 'ABSPATH' ) ) {
	exit;   // Exit if accessed directly.
}

class SC_PriceTable extends Widget_Base {
	public function get_name() {
		return 'sc-price-table';
	}

	/**
	 * Retrieve the widget title.
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Softcoders Price Table', 'SoftCoders-header-footer-elementor' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.3.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-elementor-circle';
	}

	/**
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'sce-widgets' ];
	}

	/**
	 * Register site title controls.
	 */
	protected function register_controls() {

		$this->register_general_content_controls();
		$this->register_heading_typo_content_controls();
	}

	/**
	 * Register Advanced Heading General Controls.
	 */
	protected function register_general_content_controls() {

		$this->start_controls_section(
			'section_general_fields',
			[
				'label' => __( 'General', 'SoftCoders-header-footer-elementor' ),
			]
		);
	
		$this->add_control(
			'icon_top',
			[
				'label'       => __( 'Icon', 'SoftCoders-header-footer-elementor' ),
				'type'        => Controls_Manager::ICONS,
				'label_block' => 'true',
			]
		);

		$this->add_control(
			'price',
			[
				'label'   => __( 'Price', 'SoftCoders-header-footer-elementor' ),
				'type'    => Controls_Manager::TEXT,
				'default' => __( '$23', 'SoftCoders-header-footer-elementor' ),
			]
		);

		$this->add_control(
			'price_plan',
			[
				'label'       => __( 'Price Plan', 'SoftCoders-header-footer-elementor' ),
				'type'    => Controls_Manager::TEXT,
				'default' => __( 'Standard Plan', 'SoftCoders-header-footer-elementor' ),
			]
		);

		$repeater = new Repeater();

        $repeater->add_control(
            'features',
            [
                'label' => __('Features List', 'scaddon'),
                'type' => Controls_Manager::TEXTAREA,
            ]
        );

		$repeater->add_control(
            'icon',
            [
                'label' => esc_html__( 'Icon', 'scaddon' ),
                'type' => Controls_Manager::ICON,
                'default' => 'icon-check',
                'include' => [
                    'icon-check',
                    'far fa-times-circle',
                ]
            ]
        );

		$repeater->add_control(
			'icon_select',
			[
				'label'   => esc_html__('Select Services Style', 'scaddons'),
				'type'    => Controls_Manager::SELECT,
				'default' => 'icon-check',
				'options' => [
					'icon-check' => esc_html__('Check Icon', 'scaddons'),
					'fa-times-circle' => esc_html__('Close Icon', 'scaddons'),
				],
			]
		);

		$this->add_control(
            'features_list',
            [
                'type' => Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'show_label' => false,
                'default' => [
                    [
                        'text' => esc_html__( 'Awesome Features', 'scaddon' ),
                        'icon' => 'icon-check',
                    ],
                    [
                        'text' => esc_html__( 'Responsive Pricing Table', 'scaddon' ),
                        'icon' => 'icon-check',
                    ],
                    [
                        'text' => esc_html__( 'Yearly Subscribe', 'scaddon' ),
                        'icon' => 'icon-check',
                    ],
                    [
                        'text' => esc_html__( 'Professional Design', 'scaddon' ),
                        'icon' => 'icon-check',
                    ],
                ],
                'title_field' => '{{{ features }}}',
            ]
        );

		$this->add_control(
			'read_more_text',
			[
				'label'   => __( 'Read More Text', 'SoftCoders-header-footer-elementor' ),
				'type'    => Controls_Manager::TEXT,
				'default' => __( 'Buy Package', 'SoftCoders-header-footer-elementor' ),
			]
		);

		$this->add_control(
			'read_more_link',
			[
				'label'   => __( 'Read More Link', 'SoftCoders-header-footer-elementor' ),
				'type'    => Controls_Manager::TEXT,
				'default' => __( 'Buy Package', 'SoftCoders-header-footer-elementor' ),
			]
		);
		$this->end_controls_section();
	}


	/**
	 * Register Advanced Heading Typography Controls.
	 */
	protected function register_heading_typo_content_controls() {

		$this->start_controls_section(
			'global_style',
			[
				'label' => __( 'Global Style', 'SoftCoders-header-footer-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'price_shape_background',
			[
				'label'     => __( 'Price Shape Background', 'SoftCoders-header-footer-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .sc-price-item .price-shape-one'   => 'background: {{VALUE}};',
					'{{WRAPPER}} .sc-price-item .price-shape-two'   => 'background: {{VALUE}};',
					'{{WRAPPER}} .sc-price-item .price-shape-three'   => 'background: {{VALUE}};',
				],
			]
		);
        
        $this->add_responsive_control(
			'price-padding',
			[
				'label'              => __( 'Price Padding', 'staco-core' ),
				'type'               => Controls_Manager::DIMENSIONS,
				'size_units'         => [ 'px' ],
				'selectors'          => [
					'{{WRAPPER}} .sc-price-item' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}',
				],
			]
		);

		$this->end_controls_section();
        
		$this->start_controls_section(
			'section_heading_typography',
			[
				'label' => __( 'Header Price', 'SoftCoders-header-footer-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control( 
			'icon_color',
			[
				'label'     => __( 'Icon Color', 'SoftCoders-header-footer-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'global'    => [
					'default' => Global_Colors::COLOR_PRIMARY,
				],
				'selectors' => [
					'{{WRAPPER}} .sc-price-item .sc-price-text i path'   => 'fill: {{VALUE}};',
				],
			]
		);
		
		$this->add_control(
			'Price_color',
			[
				'label'     => __( 'Price Color', 'SoftCoders-header-footer-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'global'    => [
					'default' => Global_Colors::COLOR_PRIMARY,
				],
				'selectors' => [
					'{{WRAPPER}} .sc-price-item .sc-price-text .sc-price' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'heading_typography',
				'global'   => [
					'default' => Global_Typography::TYPOGRAPHY_PRIMARY,
				],
				'selector' => '{{WRAPPER}} .sc-price-item .sc-price-text .sc-price',
			]
		);

		$this->add_responsive_control(
			'title_margin',
			[
				'label'              => __( 'Price Margin', 'staco-core' ),
				'type'               => Controls_Manager::DIMENSIONS,
				'size_units'         => [ 'px' ],
				'selectors'          => [
					'{{WRAPPER}} .sc-price-item .sc-price-text .sc-price' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}',
				],
			]
		);
        
        $this->add_control( 
			'plan_color',
			[
				'label'     => __( 'Price Plan', 'SoftCoders-header-footer-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'global'    => [
					'default' => Global_Colors::COLOR_PRIMARY,
				],
				'selectors' => [
					'{{WRAPPER}} .sc-price-item .sc-price-text .sub-title' => 'color: {{VALUE}};',
				],
			]
		);


		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'header_btn_border',
				'label' => esc_html__( 'Border', 'SoftCoders-header-footer-elementor' ),
				'selector' => '{{WRAPPER}} .sc-price-text',
			]
		);
		$this->end_controls_section();

		$this->start_controls_section(
			'section_feature',
			[
				'label' => __( 'Feature Style', 'SoftCoders-header-footer-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control( 
			'plan_text_color',
			[
				'label'     => __( 'Text Color', 'SoftCoders-header-footer-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'global'    => [
					'default' => Global_Colors::COLOR_PRIMARY,
				],
				'selectors' => [
					'{{WRAPPER}} .sc-price-item .sc-content-area .sc-content-list .sc-list li' => 'color: {{VALUE}};',
				],
			]
		);
        
		$this->add_control( 
			'feature_icon_color',
			[
				'label'     => __( 'Feature Icon Color', 'SoftCoders-header-footer-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'global'    => [
					'default' => Global_Colors::COLOR_PRIMARY,
				],
				'selectors' => [
					'{{WRAPPER}} .sc-price-item .sc-content-area .sc-content-list .sc-list li i' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'icon_font_size',
			[
				'label' => esc_html__( 'Icon Font Size', 'SoftCoders-header-footer-elementor' ),
				'type' => Controls_Manager::SLIDER,
				'show_label' => true,
				'range' => [
					'px' => [
						'max' => 100,
					],
				],
				'default' => [
					'size' => 15,
				],				

				'selectors' => [
                     '{{WRAPPER}} .sc-price-item .sc-content-area .sc-content-list .sc-list li i' => 'font-size: {{SIZE}}{{UNIT}}',
                ],
                'separator' => 'before',
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'heading_typography2',
				'global'   => [
					'default' => Global_Typography::TYPOGRAPHY_PRIMARY,
				],
				'selector' => '{{WRAPPER}} .sc-price-item .sc-content-area .sc-content-list .sc-list li i',
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'feature_border',
				'label' => esc_html__( 'Border', 'SoftCoders-header-footer-elementor' ),
				'selector' => '{{WRAPPER}} .sc-price-item .sc-content-area .sc-content-list',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_readmore',
			[
				'label' => __( 'Read More', 'SoftCoders-header-footer-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		
		$this->add_control(
			'border_radius',
			[
				'label'     => __( 'Border Radius', 'SoftCoders-header-footer-elementor' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'min' => 0,
						'max' => 200,
					],
				],
				'default'   => [
					'size' => 50,
					'unit' => 'px',
				],
				'selectors' => [
					'{{WRAPPER}} .sc-price-btn' => 'border-radius: {{SIZE}}{{UNIT}}',
				],
				'separator' => 'before',
			]
		);
		$this->start_controls_tabs( 'tabs_toggle_color' );
		$this->start_controls_tab(
			'tab_toggle_normal',
			[
				'label' => __( 'Normal', 'SoftCoders-header-footer-elementor' ),
			]
		);

		$this->add_control(
			'readmore_color',
			[
				'label'     => __( 'Color', 'SoftCoders-header-footer-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .sc-price-btn' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'readmore_bg_color',
			[
				'label'     => __( 'Background', 'SoftCoders-header-footer-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .sc-price-btn:after' => 'background: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'readmore_border_color',
			[
				'label'     => __( 'Border Color', 'SoftCoders-header-footer-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .sc-price-btn' => 'border-color: {{VALUE}};',
				],
			]
		);

        $this->add_control(
			'text_border_color',
			[
				'label'     => __( 'Text Border Color', 'SoftCoders-header-footer-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} ..sc-price-item .sc-price-text'   => 'border-: {{VALUE}};',
				],
			]
		);

        $this->add_control(
			'price_border_color',
			[
				'label'     => __( 'Price Border Color', 'SoftCoders-header-footer-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .sc-price-item'   => 'border-color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'tab_toggle_hover',
			[
				'label' => __( 'Hover', 'SoftCoders-header-footer-elementor' ),
			]
		);

		$this->add_control(
			'readmore_hover_color',
			[
				'label'     => __( 'Color', 'SoftCoders-header-footer-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .sc-price-btn:hover' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'readmore_hover_bg_color',
			[
				'label'     => __( 'Background', 'SoftCoders-header-footer-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .sc-price-btn:before' => 'background: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'readmore_hover_border_color',
			[
				'label'     => __( 'Border Color', 'SoftCoders-header-footer-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .sc-price-btn' => 'border-color: {{VALUE}};',
				],
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		$this->end_controls_section();

		
	}

	/**
	 * Render Heading output on the frontend.
	 */
	protected function render() {
		$settings = $this->get_settings();?>

		<div class="sc-price-item sc-price-bottom ">
			<div class="sc-price-text d-flex align-items-center">
				<?php if ( '' !== $settings['icon_top']['value'] ) { ?>
					<div class="sc-price-icon sc-mr-25">
						<i><?php \Elementor\Icons_Manager::render_icon( $settings['icon_top'], [ 'aria-hidden' => 'true' ] ); ?></i>			
					</div>
				<?php } ?> 

				<div class="price-text">
					<?php if (!empty($settings['price'])) { ?>
					<h2 class="sc-price"><?php echo wp_kses_post( $settings['price'] ); ?></h2>
					<?php } ?>

					<?php if (!empty($settings['price_plan'])) { ?>
					<span class="sub-title"><?php echo wp_kses_post( $settings['price_plan'] ); ?></span>
					<?php } ?>

				</div>
			</div>
			<div class="sc-content-area">
				<div class="sc-content-list sc-mb-25 sc-pt-10">
					<ul class="list-gap sc-list">
					    <?php foreach ($settings["features_list"] as $item) {
								$features = $item["features"];
								$icon_select = $item["icon_select"];?>
								<li>
									<?php if ( $icon_select ) : ?>
										<i class="far <?php echo esc_attr( $icon_select ); ?>"></i>
									<?php endif; ?>

									<?php echo $features; ?>
								</li>

						<?php } ?>
					</ul>
				</div>
				<?php if (!empty($settings['read_more_text'])) { ?>
				<div class="sc-price-button">
					<a class="sc-price-btn" href="<?php echo wp_kses_post( $settings['read_more_link'] ); ?>"><?php echo wp_kses_post( $settings['read_more_text'] ); ?></a>
				</div>
				<?php } ?>
			</div>
			<div class="price-shape-one"></div>
			<div class="price-shape-two"></div>
			<div class="price-shape-three"></div>
		</div>

		<?php
	}
		/**
		 * Render site title output in the editor.
		 */
	
}
