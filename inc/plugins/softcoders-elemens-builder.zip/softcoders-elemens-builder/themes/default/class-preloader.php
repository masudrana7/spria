<!-- preloader -->
<div id="preloader" class="preloader">
    <div class="animation-preloader">
        <div class="spinner">
            <div class="loader-icon">
                <img src="/assets/images/fav.png" alt="Boxfin" />
            </div>
        </div>
        <div class="txt-loading">
            <span data-text-preloader="B" class="letters-loading"> B </span>
            <span data-text-preloader="O" class="letters-loading"> O </span>
            <span data-text-preloader="X" class="letters-loading"> X </span>
            <span data-text-preloader="F" class="letters-loading"> F </span>
            <span data-text-preloader="I" class="letters-loading"> I </span>
            <span data-text-preloader="N" class="letters-loading"> N </span>
        </div>
        <p class="text-center">Loading</p>
    </div>
</div>