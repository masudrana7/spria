<?php
/**
 * @since 1.0.0
 */
if( is_404() ){
    return;
} else {
    do_action( 'socoders_elements_footer_before' );
    do_action( 'socoders_elements_footer' );
} ?>
</div><!-- #page -->

<!-- start scrollUp  -->
<div class="boxfin-scroll-top progress-done">
    <svg class="progress-circle svg-content" width="100%" height="100%" viewBox="-1 -1 102 102">
        <path
            d="M50,1 a49,49 0 0,1 0,98 a49,49 0 0,1 0,-98"
            style="
                transition: stroke-dashoffset 10ms linear 0s;
                stroke-dasharray: 307.919px, 307.919px;
                stroke-dashoffset: 71.1186px;
            "
        ></path>
    </svg>
    <div class="boxfin-scroll-top-icon">
        <svg
            xmlns="http://www.w3.org/2000/svg"
            aria-hidden="true"
            role="img"
            width="1em"
            height="1em"
            viewBox="0 0 24 24"
            data-icon="mdi:arrow-up"
            class="iconify iconify--mdi"
        >
            <path
                fill="currentColor"
                d="M13 20h-2V8l-5.5 5.5l-1.42-1.42L12 4.16l7.92 7.92l-1.42 1.42L13 8v12Z"
            ></path>
        </svg>
    </div>
</div>
<!-- End scrollUp  -->

 
<?php 
wp_footer(); ?>
</body>
</html> 
